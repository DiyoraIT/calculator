// forEach()

// let body = document.querySelector("body");

// let myArray = [93, 83, 72, 57, 284];

// myArray.forEach((item, index) => {
//   let h1 = document.createElement("h1");
//   h1.textContent = item;
//   body.append(h1);
// });

// let data = [
//   {
//     Img: "img - Поиск в Google.html",
//     title: "nameImg",
//   },
//   {
//     Img: "img - Поиск в Google.html",
//     title: "nameImg",
//   },
//   {
//     Img: "img - Поиск в Google.html",
//     title: "nameImg",
//   },
// ];

// let body = document.querySelector("body");

// data.forEach(basic => {
//   let parentBox = document.createElement("parent");
//   let data = document.createElement("div");

//     img.src = basic.Img;

//   data.style.border = `5px solid green`;
//   data.style.textAlign = `center`;
//   data.style.color = `pink`;
//   data.style.backgroundColor = `gray`;
//   data.style.width = `400px`;
//   data.style.height = `650px`;

//   box.appendChild(h1);
//   p.appendChild(p);
// parentBox.appendChild(box);

//   console.log();
// });

let button = document.querySelector('button')
let input = document.querySelector('input')
let h1 = document.querySelector('h1')

input.addEventListener('input', () =>{
    console.log(input.value);
    
})

// button.addEventListener('click', (event) =>{
//     event.preventDefault()
//     console.log(input.value);
//     body.style.backgroundColor = input.value
// })



function randomColor (event){
    event.preventDefault()
    console.log(input.value);
    body.style.backgroundColor = input.value
}












